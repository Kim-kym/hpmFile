const Logo = () => {
  return (
    <a href="/" className="header-logo">
      <h2>Logo</h2>
    </a>
  );
};

export default Logo;
