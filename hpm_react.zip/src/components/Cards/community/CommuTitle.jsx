const CommuTitle = ({ title }) => {
  return <h3 className="commu-title">{title}</h3>;
};

export default CommuTitle;
